import React from "react";
import { FlatList } from "react-native";
import ProductSP3 from "./ProductSP3";
export default class ListProductSP3 extends React.Component{
    //code
    constructor(){
        super();
        this.state={
            prd: null,//nhan gia tri la 1 object
        };
        this.handlePress = this.handlePress.bind(this);
        this.renderItemFlatList=this.renderItemFlatList.bind(this);
    }
    //cac ham
    //goi ham load du lieu tu API
    componentDidMount(){//ham goi tu dong khi khoi tao component
        this.getProducts();
    }
    //ham doc du lieu tu API
    async getProducts(){
        const url='https://hungnttg.github.io/shopgiay.json';//duong dan
        let response = await fetch(url,{method:'GET'});//doc du lieu
        let responseJSON = await response.json();//chuyen sang json
        //update du lieu doc duoc vao state
        this.setState({
            prd: responseJSON.products,
        });
    }
    handlePress(dataProd){
        //ham hien thi chi tiet san pham
        this.props.navigation.navigate('DetailSP4',{data:dataProd});
    }
    renderItemFlatList({item}){//ket xuat du lieu cho item
        return(
            //goi component con
            <ProductSP3 dataProd={item} handlePress={this.handlePress}/>

        );
    }
    //layout
    render(){
        return(
            <FlatList
                data={this.state.prd}
                renderItem={this.renderItemFlatList}
                numColumns={3}
                removeClippedSubviews
            />
        );
    }
}