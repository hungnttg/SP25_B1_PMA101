<?php
$s="localhost";$u="root";$p="";$db="a5";
$conn = new mysqli($s,$u,$p,$db);
$result=$conn->query("select * from mytable");
while($row[]=$result->fetch_assoc()){//doc theo mang
    $json=json_encode($row);//chuyen sang json
}
echo $json; //hien thi ket qua
$conn->close();//dong ket noi
