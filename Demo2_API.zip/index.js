const express = require('express');
const mysql = require('mysql2');
const app = express();
//ket noi csdl
const db = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'a5'
});
db.connect(err=>err);
app.get('/data',(req,res)=>{
    db.query('select * from mytable',(err,results)=>{
        if (err) return res.status(500).send(err);
        res.json(results);
    })
});
app.listen(3000,()=>{
    console.log("app dang chay o cong 3000");
});