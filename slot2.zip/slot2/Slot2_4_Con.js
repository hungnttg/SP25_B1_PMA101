import React from "react";
import { Text,View } from "react-native";
const Slot2_4_Con = ({name}) =>{
    //code
    //layout
    return(
        <View>
            <Text>Xin chao {name}</Text>
        </View>
    );
}
export default Slot2_4_Con;