import React from "react";
import { Text,View } from "react-native";
const Slot2_5_Con = ({giaTri}) =>{
    return(
        <View>
            <Text>Xin chao {giaTri}</Text>
        </View>
    );
}
export default Slot2_5_Con;